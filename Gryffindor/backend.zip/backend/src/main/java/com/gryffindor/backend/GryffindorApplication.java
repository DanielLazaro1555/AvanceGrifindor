package com.gryffindor.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GryffindorApplication {

	public static void main(String[] args) {
		SpringApplication.run(GryffindorApplication.class, args);
	}

}
